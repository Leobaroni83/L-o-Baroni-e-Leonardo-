# Sistema de Treinos - Flask + SQLite + IA (Mock)

Estrutura completa com:
- Flask
- SQLite
- IA simulada para criar treinos
- Arquitetura organizada (MVC + Services)

## Como rodar
```bash
python main.py
```

## Endpoints
POST /api/treinos  
GET /api/treinos
