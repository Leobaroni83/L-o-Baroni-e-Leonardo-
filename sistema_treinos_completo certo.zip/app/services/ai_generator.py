# Mock IA generator (no external API due to offline environment)
def gerar_treino_ia(objetivo):
    base = {
        "hipertrofia": ["Supino", "Agachamento", "Remada", "Desenvolvimento"],
        "emagrecimento": ["HIIT", "Corrida", "Bike", "Burpees"],
        "resistencia": ["Corrida leve", "Remo", "Corda", "Polichinelos"]
    }
    return base.get(objetivo.lower(), ["Caminhada", "Alongamento"])
