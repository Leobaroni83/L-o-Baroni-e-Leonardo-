from app.database.connection import get_db
from app.services.ai_generator import gerar_treino_ia

def criar_treino(nome, objetivo):
    exercicios = gerar_treino_ia(objetivo)
    db = get_db()
    db.execute(
        "INSERT INTO treinos (nome, objetivo, exercicios) VALUES (?, ?, ?)",
        (nome, objetivo, ", ".join(exercicios))
    )
    db.commit()
    return {"status": "ok", "treino": exercicios}

def listar_treinos():
    db = get_db()
    dados = db.execute("SELECT * FROM treinos").fetchall()
    return [dict(d) for d in dados]
