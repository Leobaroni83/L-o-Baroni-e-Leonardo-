from flask import Blueprint, request, jsonify
from app.controllers.treino_controller import criar_treino, listar_treinos

trainings_bp = Blueprint("trainings", __name__)

@trainings_bp.post("/")
def criar():
    dados = request.json
    return jsonify(criar_treino(dados["nome"], dados["objetivo"]))

@trainings_bp.get("/")
def listar():
    return jsonify(listar_treinos())
