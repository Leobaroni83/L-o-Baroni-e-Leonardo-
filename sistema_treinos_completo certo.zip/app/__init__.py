from flask import Flask
from app.database.connection import init_db
from app.routes.trainings import trainings_bp

def create_app():
    app = Flask(__name__)
    app.config["DATABASE"] = "treinos.db"

    init_db(app)

    app.register_blueprint(trainings_bp, url_prefix="/api/treinos")

    @app.route("/")
    def home():
        return "Sistema de Treinos OOP - Flask + SQLite"

    return app
