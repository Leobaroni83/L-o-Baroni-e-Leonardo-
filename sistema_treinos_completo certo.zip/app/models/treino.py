class Treino:
    def __init__(self, nome, objetivo, exercicios):
        self.nome = nome
        self.objetivo = objetivo
        self.exercicios = exercicios
